return {
	descriptions = {
		Mod = {
			JokerDisplay = {
				name = "JokerDisplay",
				text = {
					"Mostra informação útil abaixo dos Jokers",
					" ",
					"{C:attention}Controles:{}",
					"{C:blue}Direito do mouse ou B:{} esconde/mostra",
					"{C:blue}Esquedo do mouse ou Cima:{} minimizar/expandir",
					" ",
					"Agradecimentos especials para {C:green}Eremel{} e {C:green}OppositeWolf770{}",
					" ",
					"Tradução pro russo: {C:green}WholeHorse{}",
					"Tradução pro francês: {C:green}SDM_0{}",
					"Tradução pro português: {C:green}naumazeredo{}",
					"Tradução pro italiano: {C:green}fleshness{}",
					"Tradução pro alemão: {C:green}GunnableScum{}",
					"Tradução pro holandês: {C:green}Soulsphere{}",
					"Tradução pro chinês tradicional: {C:green}wilfredam0418{}",
					"Simplified Chinese localization by: {C:green}ChromaPIE",
					"Japanese localization by: {C:green}koukichi_kkc",
				},
			},
		},
	},
	misc = {
		dictionary = {
			jdis_enabled = "Habilitado",
			jdis_hide_by_default = "Esconder por padrão",
			jdis_hide_empty = "Esconder quando vazio",
			jdis_shift_to_hide = "Shift + Direito do mouse para esconder",
			jdis_disable_collapse = "Desabilitar minimizar",
			jdis_disable_perishable = "Desabilitar Perecível",
			jdis_disable_rental = "Desabilitar Alugado",
			jdis_modifiers = "Modificadores",
			jdis_reminders = "Lembretes",
			jdis_extras = "Extras",
			jdis_default_display = "Padrão",
			jdis_small_display = "Minimizado",
			jdis_active = "Ativo!",
			jdis_inactive = "Inativo",
			jdis_all_suits = "Todos naipes",
			jdis_author = 'Autor'
		},
		v_dictionary = {
			jdis_odds = "#1# em #2#",
			jdis_rank_of_suit = "#1# de #2#",
		},
	},
}
