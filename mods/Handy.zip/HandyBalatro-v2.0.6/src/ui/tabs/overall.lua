function Handy.UI.overall_tab_UIBox()
	local logo = {
		n = G.UIT.R,
		config = { align = "cm", colour = { 0, 0, 0, 0.1 }, r = 0.25, padding = 0.2 },
		nodes = {
			{
				n = G.UIT.C,
				config = { align = "cm" },
				nodes = {
					Handy.UI.CP.logo(0.8),
					Handy.UI.CP.r_sep(0.15),
					{
						n = G.UIT.R,
						config = { align = "cm" },
						nodes = {
							{
								n = G.UIT.T,
								config = {
									text = Handy.L.variable("Handy_version_by", { Handy.version, "SleepyG11" }),
									scale = 0.28,
									colour = G.C.UI.TEXT_LIGHT,
								},
							},
						},
					},
					Handy.UI.CP.r_sep(0.3),
					{
						n = G.UIT.R,
						config = {
							align = "cm",
							colour = Handy.cc.handy.enabled and G.C.CHIPS or G.C.MULT,
							r = 0.1,
							padding = 0.25,
							shadow = true,
							hover = true,
							button = "handy_overall_toggle_mod",
							focus_args = {
								nav = "wide",
							},
						},
						nodes = {
							{
								n = G.UIT.T,
								config = {
									ref_table = {
										text = Handy.L.dictionary(
											Handy.cc.handy.enabled and "handy_mod_enabled" or "handy_mod_disabled"
										),
									},
									ref_value = "text",
									scale = 0.4,
									colour = G.C.UI.TEXT_LIGHT,
									shadow = true,
								},
							},
						},
					},
				},
			},
			{
				n = G.UIT.C,
				config = {},
				nodes = {
					Handy.L.description("Handy_Other", "overall_title", {
						vars = {},
						default_col = adjust_alpha(G.C.UI.TEXT_LIGHT, 0.9),
						scale = 0.25 / 0.32,
						minh = 0.25,
					}),
				},
			},
		},
	}

	local b = function(args)
		return {
			n = G.UIT.R,
			config = {
				align = "cm",
				colour = args.colour or G.C.CHIPS,
				r = 0.1,
				padding = 0.25,
				shadow = true,
				hover = true,
				button = args.button or "handy_noop",
				minw = 3.25,
				maxw = 3.25,
				minh = 0.8,
				func = args.func or nil,
				focus_args = args.focus_args or nil,
			},
			nodes = {
				{
					n = G.UIT.T,
					config = {
						text = Handy.L.tab(args.label),
						scale = 0.35,
						colour = args.text_colour or G.C.UI.TEXT_LIGHT,
						shadow = true,
					},
				},
			},
		}
	end

	local buttons = {
		n = G.UIT.R,
		config = { align = "cm", padding = 0.15, r = 0.25, colour = { 0, 0, 0, 0.1 } },
		nodes = {
			{
				n = G.UIT.R,
				nodes = {
					{
						n = G.UIT.R,
						config = { align = "cm" },
						nodes = {
							{
								n = G.UIT.C,
								config = { minw = 3.25, maxw = 3.25 },
								nodes = {
									b({ label = "General", button = "handy_appearance" }),
									Handy.UI.CP.r_sep(0.1),
									b({ label = "Speed & Animations", button = "handy_speed_n_animations" }),
								},
							},
							Handy.UI.CP.c_sep(0.1),
							{
								n = G.UIT.C,
								config = { minw = 3.25, maxw = 3.25 },
								nodes = {
									b({
										label = "Fast hand selection",
										colour = G.C.DARK_EDITION,
										button = "handy_hand_selection",
									}),
									Handy.UI.CP.r_sep(0.1),
									b({ label = "Quick buy/sell/use", button = "handy_insta_actions" }),
								},
							},
							Handy.UI.CP.c_sep(0.1),
							{
								n = G.UIT.C,
								config = { minw = 3.25, maxw = 3.25 },
								nodes = {
									b({
										label = "Vanilla keybinds",
										button = "handy_vanilla_keybinds",
										focus_args = {
											type = "handy",
											handy_side_panel_bug = true,
										},
									}),
									Handy.UI.CP.r_sep(0.1),
									b({
										label = "Highlight movement",
										button = "handy_move_highlight",
										focus_args = {
											type = "handy",
											handy_side_panel_bug = true,
										},
									}),
								},
							},
						},
					},
				},
			},
		},
	}

	local buttons_2 = {
		n = G.UIT.R,
		config = { align = "cm", padding = 0.15, r = 0.25, colour = { 0, 0, 0, 0.1 } },
		nodes = {
			{
				n = G.UIT.R,
				nodes = {
					{
						n = G.UIT.R,
						config = { align = "cm" },
						nodes = {
							{
								n = G.UIT.C,
								config = { minw = 3.25, maxw = 3.25 },
								nodes = {
									b({ label = "MP Extension", button = "handy_mp_extension", colour = Handy.UI.C.MP }),
								},
							},
							Handy.UI.CP.c_sep(0.1),
							{
								n = G.UIT.C,
								config = { minw = 3.25, maxw = 3.25 },
								nodes = {
									Handy.updater and b({
										label = "Updater",
										button = "handy_updater",
										colour = G.C.CHIPS,
										func = "handy_updates_alert",
									}) or b({
										label = "Thunderstore",
										button = "handy_open_thunderstore_page",
										colour = HEX("24ffab"),
										func = "handy_updates_alert",
									}),
								},
							},
							Handy.UI.CP.c_sep(0.1),
							{
								n = G.UIT.C,
								config = { minw = 3.25, maxw = 3.25 },
								nodes = {
									b({
										label = "Dangerous",
										button = "handy_dangerous",
										colour = G.C.MULT,
										focus_args = {
											type = "handy",
											handy_side_panel_bug = true,
										},
									}),
								},
							},
						},
					},
				},
			},
		},
	}

	local compat_mode_message = nil
	if SMODS and SMODS.Mods and not SMODS.Mods.Handy then
		compat_mode_message = {
			n = G.UIT.R,
			config = {
				align = "cm",
				maxw = 9.5,
			},
			nodes = {
				{
					n = G.UIT.T,
					config = {
						text = Handy.L.dictionary("handy_smods_compat_mode"),
						scale = 0.35,
						colour = Handy.UI.C.MP,
						shadow = true,
						maxw = 9.5,
					},
				},
			},
		}
	end

	return {
		n = G.UIT.C,
		config = { align = "cm", padding = 0.1, colour = { 0, 0, 0, 0.1 }, minh = 5, minw = 5, r = 0.25 },
		nodes = { logo, buttons, buttons_2, compat_mode_message },
	}
end

function Handy.UI.overall_tab()
	return {
		n = G.UIT.ROOT,
		config = { colour = G.C.CLEAR },
		nodes = {
			Handy.UI.overall_tab_UIBox(),
		},
	}
end

G.FUNCS.handy_overall_toggle_mod = function(e)
	Handy.cc.handy.enabled = not Handy.cc.handy.enabled
	Handy.config.request_save()

	if Handy.cc.handy.enabled then
		e.config.colour = G.C.CHIPS
		e.children[1].config.ref_table.text = Handy.L.dictionary("handy_mod_enabled")
		G.E_MANAGER:clear_queue("handy_chars")
		Handy.UI.CHAR.set_sprite_pos("me", "happy")
		Handy.UI.CHAR.jump("me")
		delay(0.2, "handy_chars")
		Handy.UI.CHAR.set_sprite_pos("me", "default", true)
	else
		e.config.colour = G.C.MULT
		e.children[1].config.ref_table.text = Handy.L.dictionary("handy_mod_disabled")
		Handy.UI.CHAR.set_sprite_pos("me", "scary")
		Handy.UI.CHAR.jump("me")
	end
end

G.FUNCS.handy_open_thunderstore_page = function()
	love.system.openURL("https://thunderstore.io/c/balatro/p/SleepyG11/Handy")
end
